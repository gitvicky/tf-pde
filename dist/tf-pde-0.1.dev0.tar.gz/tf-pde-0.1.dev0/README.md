# Neural PDE
Autodiff based PDE solver implemented on the Tensorflow 2.x API. Package distribution under the MIT License
